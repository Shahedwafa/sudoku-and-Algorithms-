____________________________________________________________________________
    Copyright (C) 2009
    Babak Ahmadi [babak dot ahmadi at iais dot fraunhofer dot de]
    Fabian Hadiji [fabian dot hadiji at iais dot fraunhofer dot de]
    Kristian Kersting (coordination) [kristian dot kersting at iais dot fraunhofer dot de]

    STREAM Project at
        Fraunhofer IAIS, Sankt Augustin, Germany, and 
        KDML, Unversity of Bonn, Germany 

    This file is part of libSTREAM.

    libSTREAM is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    libSTREAM is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
 
    You should have received a copy of the GNU General Public License 
    along with this program; if not, see <http://www.gnu.org/licenses/>.
____________________________________________________________________________


This toolbox libSTREAM provides an implementation of the CBP algorithm introduced in 

"K. Kersting, B. Ahmadi, S. Natarajan. Counting Belief Propagation.
In A. Ng, J. Bilmes, editor(s), UAI-09, Montreal, Canada."

please cite as:

@conference { kersting09uai,
author = {K. Kersting and B. Ahmadi and S. Natarajan},
title = {Counting Belief Propagation},
year = {2009},
booktitle = {Proceedings of the 25th Conference on Uncertainty in Artificial Intelligence (UAI-09)},
editor = {A. Ng, J. Bilmes},
note = {to appear},
month = {June 18-21},
address = {Montreal, Canada}
}

The current implementation has not been optimized yet and is work in progress. We appreciate any feedback.

It extends and heavily uses the libDAI software package:
J. M. Mooij (2009) "libDAI 0.2.3: A free/open source C++ library for Discrete Approximate Inference methods"
to be found at: http://www.libdai.org


installing libDAI
-----------------
libSTREAM extends the libDAI library (v. 0.2.3), which is therefore required for CBP.
* download libDAI (v. 0.2.3)
* follow the instructions given to compile the libDAI library
* libdai.a binary file is created in libDAI/lib folder


installing libSTREAM
--------------------
* The installation of libSTREAM creates a shared C++ library and corresponding Python bindings
* edit the makefile:
	- find the line specifying the path to libDAI and edit if necessary (e.g. LIB_DAI := /home/stream/libDAI)
	- find the line specifying the path to Boost includes and edit if necessary (e.g. BOOST := /usr/include/boost)
	- find the line specifying the path to Boost libraries and edit if necessary (BOOST_LIB := /usr/lib)
	- find the line specifying the path to Python includes and edit if necessary (e.g. PYTHON := /usr/include/python2.6)
* compile libSTREAM by invoking make, this creates the binary files libSTREAM.so (C++ library) and libSTREAMWrapper.so (Python wrapper)

running the Python examples
---------------------------
* The folder example/python/ contains several example scripts which examplify the usage of the libSTREAM
* In order to run any of the examples which use MLNs, it is necessary to install the python module pymlns (http://www9-old.in.tum.de/people/jain/mlns/)
* The pymlns module is primarily required to parse MLN files
* Download and install pymlns as instructed
* Add pymlns to your PYTHONPATH:
	export PYTHONPATH=$PYTHONPATH:/path/to/pymlns/
* Add the libSTREAMWrapper to your PYTHONPATH
	export PYTHONPATH=$PYTHONPATH:/path/to/libSTREAMWrapper.so/
* The libSTREAM additionally contains a Python module that connects the pymlns module with our bindings, this package has to be added to the PYTHONPATH as well:
	export PYTHONPATH=$PYTHONPATH:/src/main/python
* Add the paths to the libSTREAM library and the Boost libraries (e.g. /usr/lib) to your shared library path:
	export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/path/to/libSTREAM.so:/path/to/boost_libraries
* The folder example/python/ also contains a small MLN which can be used to test the insallation

runMln.py
---------
* This script reads an MLN file, converts it to an FactorGraph and runs CBP on it:
	./eaxmple/runMln.py mlnfilename

mln2cfg.py
----------
* convert mln to cfg format (in libSTREAM style) by:
	./example/mln2fg.py mlnfilename outfilename

mln2fg.py
---------
* convert mln to fg format (in libDAI style, but order of variables as in MLN formulae) by:
	./example/mln2fg.py mlnfilename outfilename

runCfg.py
---------
* run inference on a libSTREAM style factor graph. This allows to read compressed factorgraphs
	./example/runCfg.py cfgfilename

runFg.py
--------
* run inference on a libDAI style factor graphs. 
	./example/runFg.py

running the C++ example
-----------------------
* edit the makefile, find the line specifying the path to libDAI and edit if necessary (e.g. LIB\_DAI $:=$ /home/stream/libDAI/)
* compile by invoking make
* run example by ./example factorgraph_filename* you can either input a factor graph in the format specified by libDAI (http://www.kyb.mpg.de/bs/people/jorism/libDAI/fileformat.txt)
or alternatively use the provided script to convert mlns to the .fg file format (as shown below)








